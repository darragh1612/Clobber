package com.example.paypal.config;

public class Config {
    public static final String PAYPAL_CLIENT_ID = "AaWoqMLA5pIWavXC4yJSrE6Nz2EE7W-6S9cAPbgyHm3PZgXVrVM142om7HNZ0BJlD4DfOY756v4HwWGw";
}
